package entities;


public class HotelChainEmail {
    private String brand;
    private String address;
    private String email;

    public HotelChainEmail(String address, String email) {
        this.brand = brand;
        this.address = address;
        this.email = email;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
