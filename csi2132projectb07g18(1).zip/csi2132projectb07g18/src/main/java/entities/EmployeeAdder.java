package entities;

public class EmployeeAdder {
    private int workId;
    private String address;
    private String brand;
    private String location;

    public EmployeeAdder(int workId, String address, String brand, String location) {
        this.workId = workId;
        this.address = address;
        this.brand = brand;
        this.location = location;
    }

    @Override
    public String toString() {
        return "EmployeeAdder{" +
                "workId=" + workId +
                ", address=" + address +
                ", brand='" + brand + '\'' +
                ", location=" + location +
                '}';
    }

    public int getWorkId() {
        return workId;
    }

    public void setWorkId(int workId) {
        this.workId = workId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
