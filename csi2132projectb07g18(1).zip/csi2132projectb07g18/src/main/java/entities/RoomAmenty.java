package entities;

public class RoomAmenty {
    private String address;
    private String brand;
    private int roomNumber;
    private String amenity;

    public RoomAmenty(String address, String brand, int roomNumber, String amenity) {
        this.address = address;
        this.brand = brand;
        this.roomNumber = roomNumber;
        this.amenity = amenity;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getAmenity() {
        return amenity;
    }

    public void setAmenity(String amenity) {
        this.amenity = amenity;
    }
}
