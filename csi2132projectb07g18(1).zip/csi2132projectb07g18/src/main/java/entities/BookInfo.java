package entities;

public class BookInfo {
    private int roomNumber;
    private String brand;
    private String address;
    private int custId;
    private int bookId;
    private String roomType;
    private int NumOccupants;
    private String year;
    private String month;
    private String day;

    public BookInfo(int roomNumber, String brand, String address, int custId, int bookId, String roomType, int numOccupants, String year, String month, String day) {
        this.roomNumber = roomNumber;
        this.brand = brand;
        this.address = address;
        this.custId = custId;
        this.bookId = bookId;
        this.roomType = roomType;
        NumOccupants = numOccupants;
        this.year = year;
        this.month = month;
        this.day = day;
    }

    @Override
    public String toString() {
        return "BookInfo{" +
                "roomNumber=" + roomNumber +
                ", brand='" + brand + '\'' +
                ", address=" + address +
                ", custId=" + custId +
                ", bookId=" + bookId +
                ", roomType='" + roomType + '\'' +
                ", NumOccupants=" + NumOccupants +
                ", year='" + year + '\'' +
                ", month='" + month + '\'' +
                ", day='" + day + '\'' +
                '}';
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public int getNumOccupants() {
        return NumOccupants;
    }

    public void setNumOccupants(int numOccupants) {
        NumOccupants = numOccupants;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
}
