package entities;

public class CustAdder {
    private int custId;
    private String location;

    public CustAdder(int custId, String location) {
        this.custId = custId;
        this.location = location;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "CustAdder{" +
                "custId=" + custId +
                ", location=" + location +
                '}';
    }
}
