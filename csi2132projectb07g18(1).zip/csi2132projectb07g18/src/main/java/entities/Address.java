package entities;

public class Address {
    private String location;
    private String country;
    private String provinceOrState;
    private String city;
    private String streetNum;
    private String streetName;
    private String aptNum;
    private String zip;

    public Address(String location,String country,  String provinceOrState,String city, String streetNum, String streetName, String aptNum, String zip) {
        this.location = location;
        this.country = country;
        this.provinceOrState = provinceOrState;
        this.city = city;
        this.streetNum = streetNum;
        this.streetName = streetName;
        this.aptNum = aptNum;
        this.zip = zip;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvinceOrState() {
        return provinceOrState;
    }

    public void setProvinceOrState(String provinceOrState) {
        this.provinceOrState = provinceOrState;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreetNum() {
        return streetNum;
    }

    public void setStreetNum(String streetNum) {
        this.streetNum = streetNum;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getAptNum() {
        return aptNum;
    }

    public void setAptNum(String aptNum) {
        this.aptNum = aptNum;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
}
