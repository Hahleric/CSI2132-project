package entities;

public class EmployeePhone {
    private int wordId;
    private String brand;
    private String address;


    private String phone;



    public EmployeePhone(int wordId, String brand, String address, String phone) {
        this.wordId = wordId;
        this.brand = brand;
        this.address = address;
        this.phone = phone;
    }
    public int getWordId() {
        return wordId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setWordId(int wordId) {
        this.wordId = wordId;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return "EmployeePhone{" +
                "wordId=" + wordId +
                ", phone='" + phone + '\'' +
                '}';
    }
}
