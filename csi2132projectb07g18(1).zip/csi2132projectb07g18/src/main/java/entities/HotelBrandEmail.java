package entities;

public class HotelBrandEmail {
    private String brand;
    private String email;

    public HotelBrandEmail(String brand, String email) {
        this.brand = brand;
        this.email = email;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
