package entities;

public class HotelBrand {
    private String brand;
    private String mainOfficeLocation;
    private String numChains;

    public HotelBrand(String brand, String mainOfficeLocation, String numChains) {
        this.brand = brand;
        this.mainOfficeLocation = mainOfficeLocation;
        this.numChains = numChains;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getMainOfficeLocation() {
        return mainOfficeLocation;
    }

    public void setMainOfficeLocation(String mainOfficeLocation) {
        this.mainOfficeLocation = mainOfficeLocation;
    }

    public String getNumChains() {
        return numChains;
    }

    public void setNumChains(String numChains) {
        this.numChains = numChains;
    }
}
