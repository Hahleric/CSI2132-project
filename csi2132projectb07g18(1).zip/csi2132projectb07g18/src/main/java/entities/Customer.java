package entities;

public class Customer {
    private int ID;
    private String firstName;
    private String middleName;
    private String lastName;
    private String sinNumber;
    private String dateRegistration;

    public Customer(int customer_id ,String first_name,String middleName,String last_name,String sinNumber,String dateRegistration) {
        this.ID = customer_id;
        this.firstName = first_name;
        this.middleName = middleName;
        this.lastName = last_name;
        this.dateRegistration = dateRegistration;
        this.sinNumber = sinNumber;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "ID=" + ID +
                ", firstName='" + firstName + '\'' +
                ", middleName='" + middleName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", sinNumber='" + sinNumber + '\'' +
                ", dateRegistration='" + dateRegistration + '\'' +
                '}';
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSinNumber() {
        return sinNumber;
    }

    public void setSinNumber(String sinNumber) {
        this.sinNumber = sinNumber;
    }

    public String getDateRegistration() {
        return dateRegistration;
    }

    public void setDateRegistration(String dateRegistration) {
        this.dateRegistration = dateRegistration;
    }
}
