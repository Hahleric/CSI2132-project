package entities;

public class HotelAdder {
    private String address;
    private String brand;
    private String location;

    public HotelAdder(String address, String brand, String location) {
        this.address = address;
        this.brand = brand;
        this.location = location;
    }

    @Override
    public String toString() {
        return "HotelAdder{" +
                "address=" + address +
                ", brand='" + brand + '\'' +
                ", location=" + location +
                '}';
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
