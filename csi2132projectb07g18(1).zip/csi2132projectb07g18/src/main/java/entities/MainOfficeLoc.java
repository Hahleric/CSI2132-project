package entities;

public class MainOfficeLoc {
    private String brand;
    private String location;

    @Override
    public String toString() {
        return "MainOfficeLoc{" +
                "brand='" + brand + '\'' +
                ", location='" + location + '\'' +
                '}';
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public MainOfficeLoc(String brand, String location) {
        this.brand = brand;
        this.location = location;
    }
}
