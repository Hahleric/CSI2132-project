package entities;

public class EmployeePosition {
    private int workId;
    private String brand;
    private String address;
    private String position;

    public EmployeePosition(int workId, String brand, String address, String position) {
        this.workId = workId;
        this.brand = brand;
        this.address = address;
        this.position = position;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getWorkId() {
        return workId;
    }

    public void setWorkId(int workId) {
        this.workId = workId;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    @Override
    public String toString() {
        return "EmployeePosition{" +
                "workId=" + workId +
                ", position='" + position + '\'' +
                '}';
    }
}
