package entities;


public class Room {
    private int roomNumber; // primary key
    private String address;
    private String brand;
    private double price;
    private int capacity;
    private boolean isExtended;
    private boolean isSeaView;
    private boolean isMountainView;


    public Room(int roomNumber, String address, String brand,double price, int capacity, boolean isExtended,boolean isSeaView,boolean isMountainView) {
        this.address = address;
        this.brand = brand;
        this.roomNumber = roomNumber;
        this.price = price;
        this.capacity = capacity;
        this.isExtended = isExtended;
        this.isMountainView = isMountainView;
        this.isSeaView = isSeaView;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public boolean isExtended() {
        return isExtended;
    }

    public void setExtended(boolean extended) {
        isExtended = extended;
    }

    public boolean isSeaView() {
        return isSeaView;
    }

    public void setSeaView(boolean seaView) {
        isSeaView = seaView;
    }

    public boolean isMountainView() {
        return isMountainView;
    }

    public void setMountainView(boolean mountainView) {
        isMountainView = mountainView;
    }

    public String toStringInfo(){
        return "Room{ " +
                "price = " + price  +'\'' +
                ", capacity = " + capacity  +'\'' +
                ", isExtended = " + isExtended  +'\'' +
                ", isMountainView = " + isMountainView +'\'' +
                ", isSeaView = " + isSeaView + '\'' +
                '}';
    }
}
