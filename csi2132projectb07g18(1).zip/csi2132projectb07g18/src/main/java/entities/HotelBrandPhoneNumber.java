package entities;

public class HotelBrandPhoneNumber {
    private String brand;
    private String phoneNumber;
    public HotelBrandPhoneNumber(String brand, String phoneNumber) {
        this.brand = brand;
        this.phoneNumber = phoneNumber;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }


}
