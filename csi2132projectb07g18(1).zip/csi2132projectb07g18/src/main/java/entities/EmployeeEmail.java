package entities;

public class EmployeeEmail {
    private int workId;
    private String address;
    private String brand;
    private String email;

    public EmployeeEmail(int workId, String brand, String address, String email) {
        this.workId = workId;
        this.address = address;
        this.brand = brand;
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getWorkId() {
        return workId;
    }

    public void setWorkId(int workId) {
        this.workId = workId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "EmployeeEmail{" +
                "workId=" + workId +
                ", email='" + email + '\'' +
                '}';
    }
}
