package entities;


public class HotelChain {
    private String address; // primary key
    private String brand;
    private int star;
    private int numOfRooms;
    private String manager;

    public HotelChain(String address, String brand, int star, int numOfRooms, String manager) {
        this.address = address;
        this.brand = brand;
        this.star = star;
        this.numOfRooms = numOfRooms;
        this.manager = manager;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }

    public int getNumOfRooms() {
        return numOfRooms;
    }

    public void setNumOfRooms(int numOfRooms) {
        this.numOfRooms = numOfRooms;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }
}
