package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

import dao.EmployeeDao;
import entities.Employee;
@WebServlet(urlPatterns = "/ListAllEmployeesServlet")
public class ListAllEmployeesServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String hotelBrand = req.getParameter("brand");

        EmployeeDao employeeDao = new EmployeeDao();
        employeeDao.connect();
        List<Employee> employees = employeeDao.findEmployeeByHotelBrand(hotelBrand);
        employeeDao.close();
        System.out.println(hotelBrand);
        System.out.println(employees);
        System.out.println(employees.size());

        HttpSession session1 = req.getSession();
        if(employees.size() == 0){
            req.setAttribute("message", "No such hotel brand!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
            return;
        }else{
            session1.setAttribute("employees", employees);
            resp.sendRedirect("AllEmployees.jsp");
            return;
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
