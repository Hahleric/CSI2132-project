package servlet;

import dao.RoomDao;
import entities.Room;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet(urlPatterns = "/roomInfo2")
public class roomInfo2 extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String roomNum = req.getParameter("roomnumber");
        int rNum = Integer.parseInt(roomNum);
        String brand = req.getParameter("hbrand");
        String addr = req.getParameter("address");

        RoomDao roomDao = new RoomDao();
        roomDao.connect();
        Room room=roomDao.select(rNum,brand,addr);
        roomDao.close();

        if(room == null){
            req.setAttribute("message", "The room doesn't exist!");
            req.getRequestDispatcher("LoginSuccess.jsp").forward(req, resp);
            return;
        }else{
            String r = room.toStringInfo();
            req.setAttribute("message", r);
            req.getRequestDispatcher("LoginSuccess.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
