package servlet;

import dao.UserDao;
import entities.Customer;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
@WebServlet(urlPatterns = "/deleteCustomer")
public class deleteCustomer extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String cid = req.getParameter("cid");
        int id = Integer.parseInt(cid);
        UserDao userDao = new UserDao();
        userDao.connect();
        Customer cus = userDao.findCusById(id);
        if(cus == null){
            userDao.close();
            req.setAttribute("message", "No such customer in the hotel!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
            return;
        }

        try{
            userDao.removeCusById(id);
            userDao.close();
            req.setAttribute("message", "Delete Success!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
            return;
        }catch(Exception e){
            req.setAttribute("message", "Delete Fail!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}