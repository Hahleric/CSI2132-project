package servlet;

import dao.BookInfoDao;
import dao.HotelChainDao;
import entities.HotelChain;
import entities.Room;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = "/SearchBookedRooms")
public class SearchBookedRooms extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String brand = req.getParameter("hotel");
        String address = req.getParameter("address");
        String year = req.getParameter("year");
        String month = req.getParameter("month");
        String day = req.getParameter("day");
        System.out.println(brand+address+year+month+day);

        HotelChainDao htcd = new HotelChainDao();
        htcd.connect();
        HotelChain htc = htcd.select(address,brand);
        htcd.close();

        HttpSession session5 = req.getSession();
        if(htc == null){
            req.setAttribute("message", "No such hotel chain!");
            req.getRequestDispatcher("employee.jsp").forward(req, resp);
            return;
        }else{
            BookInfoDao bookInfoDao = new BookInfoDao();
            bookInfoDao.connect();
            List<Room> brooms = bookInfoDao.searchBookedRooms(brand,address,year,month,day);
            bookInfoDao.close();
            if(brooms.size() == 0){
                req.setAttribute("message", "No booked rooms in the hotel!");
                req.getRequestDispatcher("employee.jsp").forward(req, resp);
                return;
            }else{
                session5.setAttribute("brooms", brooms);
                resp.sendRedirect("BookedRooms.jsp");
                return;
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
