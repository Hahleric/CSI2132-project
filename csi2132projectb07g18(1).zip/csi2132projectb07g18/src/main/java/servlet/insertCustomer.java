package servlet;

import dao.UserDao;
import entities.Customer;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
@WebServlet(urlPatterns = "/insertCustomer")
public class insertCustomer extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       String cid = req.getParameter("id");
        int id = Integer.parseInt(cid);
        String firstName = req.getParameter("firstname");
        String middleName = req.getParameter("middleName");
        String lastName = req.getParameter("lastname");
        String sinNumber = req.getParameter("sinNumber");
        String dateR = req.getParameter("dateRegistration");

        UserDao userDao = new UserDao();
        userDao.connect();
        Customer customer = new Customer(id,firstName,middleName,lastName,sinNumber,dateR);
        try{
            userDao.insertCus(customer);
            userDao.close();
            req.setAttribute("message", "Insert Success!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
            return;
        }catch(Exception e){
            req.setAttribute("message", "Insert Fail!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
