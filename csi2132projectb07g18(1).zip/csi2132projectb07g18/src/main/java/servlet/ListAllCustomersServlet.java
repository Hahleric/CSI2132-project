package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

import dao.UserDao;
import entities.Customer;
@WebServlet(urlPatterns = "/ListAllCustomersServlet")
public class ListAllCustomersServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        UserDao userdao = new UserDao();
        userdao.connect();
        ArrayList<Customer> customers = userdao.getAllUsers();
        userdao.close();
        HttpSession session2 = req.getSession();
        if(customers.size() == 0){
            req.setAttribute("message", "No customer in the hotel yet");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
            return;
        }else{
            session2.setAttribute("customers", customers);
            resp.sendRedirect("AllCustomers.jsp");
            return;
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}