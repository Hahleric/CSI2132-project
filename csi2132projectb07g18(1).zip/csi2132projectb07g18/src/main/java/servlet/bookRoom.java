package servlet;

import dao.BookInfoDao;
import dao.RoomDao;
import entities.BookInfo;
import entities.Room;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
@WebServlet(urlPatterns = "/bookRoom")
public class bookRoom extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String roomNumber = req.getParameter("roomnumber");
        String brand = req.getParameter("hbrand");
        String address = req.getParameter("address");
        String cid = req.getParameter("cid");
        String roomType = req.getParameter("roomtype");
        String nOcc = req.getParameter("numoccu");
        String year = req.getParameter("year");
        String month = req.getParameter("month");
        String day = req.getParameter("day");
        int roomnumber = Integer.parseInt(roomNumber);
        int cusid = Integer.parseInt(cid);
        int NumOccup = Integer.parseInt(nOcc);
        String bidd = year+month+day+cid;
        int bid = Integer.parseInt(bidd);
        System.out.println(bid);

        RoomDao room = new RoomDao();
        room.connect();
        Room r = room.select(roomnumber,brand,address);
        room.close();
        if(r == null){
            req.setAttribute("message", "No such room, please choose another one.");
            req.getRequestDispatcher("LoginSuccess.jsp").forward(req, resp);
            return;
        }


        BookInfoDao bookid = new BookInfoDao();
        bookid.connect();
        boolean isBooked = bookid.findIfRoomBooked(roomnumber,brand,address,year,month,day);
        if (isBooked = true){
            req.setAttribute("message", "The room has been reserved, please choose another one.");
            req.getRequestDispatcher("LoginSuccess.jsp").forward(req, resp);
            bookid.close();
            return;
        }else{
            BookInfo bookInfo = new BookInfo(roomnumber,brand,address,cusid,bid,roomType,NumOccup,year,month,day);
            bookid.insert(bookInfo);
            bookid.close();
            req.setAttribute("message", "Book success, your book id is: "+bidd);
            req.getRequestDispatcher("LoginSuccess.jsp").forward(req, resp);
            return;
        }


    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
