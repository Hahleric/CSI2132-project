package servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import dao.LoginDao;
import entities.Customer;
import entities.Employee;
@WebServlet(urlPatterns = "/CustomerServlet")
public class CustomerServlet extends HttpServlet{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String userId = req.getParameter("id");
        String firstName = req.getParameter("firstname");
        String role = req.getParameter("role");
        int id = Integer.parseInt(userId);
        System.out.println(userId + firstName);

        LoginDao loginDao = new LoginDao();
        loginDao.connect();
        String cfn = loginDao.findCustomerFirstNameById(id);
        String efn = loginDao.findEmployeeFirstNameById(id);
        loginDao.close();

        if (!firstName.equals(cfn) && !firstName.equals(efn)) {
            req.setAttribute("message", "User is not exist ot the password is incorrect!");
            req.getRequestDispatcher("index.jsp").forward(req, resp);
            return;
        }
        HttpSession session = req.getSession();
        session.setAttribute("firstname", firstName);
        if(role.equals("customer")){
            resp.sendRedirect("LoginSuccess.jsp");
            return;
        }
        if(role.equals("employee")){
            resp.sendRedirect("employee.jsp");
            return;
        }
        if(role.equals("manager")){
            resp.sendRedirect("manager.jsp");
            return;
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
