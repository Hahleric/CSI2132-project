package servlet;

import dao.RoomDao;
import entities.Room;
import entities.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
@WebServlet(urlPatterns = "/ListAllRooms")
public class ListAllRooms extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String hotelBrand = req.getParameter("hotelbrand");
        RoomDao roomDao = new RoomDao();
        roomDao.connect();
        List<Room> rooms = (List<Room>) roomDao.findRoomByBrand(hotelBrand);
        roomDao.close();
        System.out.println(rooms);

        HttpSession session3 = req.getSession();
        if(rooms.size() == 0){
            req.setAttribute("message", "The hotel is non-exist or no room in the hotel!");
            req.getRequestDispatcher("manager.jsp").forward(req, resp);
            return;
        }else{
            session3.setAttribute("rooms", rooms);
            resp.sendRedirect("AllRooms.jsp");
            return;
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }
}
