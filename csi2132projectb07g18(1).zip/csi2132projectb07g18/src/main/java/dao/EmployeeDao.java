package dao;

import entities.Address;
import entities.CustAdder;
import entities.Employee;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class EmployeeDao extends  Dao{
    public void insert(Employee employee){
        try {
            sql = "insert into employee values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1, employee.getWorkId());
            ps.setString(2, employee.getAddress());
            ps.setString(3, employee.getBrand());
            ps.setString(4, employee.getFirstName());
            ps.setString(5, employee.getMiddleName());
            ps.setString(6, employee.getLastName());
            ps.setDouble(7, employee.getSalary());
            ps.setLong(8, employee.getSinNumber());
            ps.setString(9, employee.getYear());
            ps.setString(10, employee.getMonth());
            ps.setString(11, employee.getDay());
            ps.executeUpdate();
            System.out.println(1);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
//        private int workId;
//        private Address address;
//        private String brand;
//        private String firstName;
//        private String middleName;
//        private String lastName;
//        private double salary;
//        private long sinNumber;
//        private String year;
//        private String month;
//        private String day;

    }
    public void delete(int workId, String address, String brand){
        try{
            sql = "delete * from employee where work_ID = ? and address = ? and brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,address);
            ps.setString(3,brand);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public Employee select(int workId, String address, String brand){
        Employee employee = null;
        try{
            sql = "select * from employee where work_ID = ? and address = ? and brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,address);
            ps.setString(3,brand);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                String fn = resultSet.getString(4);
                String mn = resultSet.getString(5);
                String ln = resultSet.getString(6);
                double s = resultSet.getDouble(7);
                long sin = resultSet.getLong(8);
                String y = resultSet.getString(9);
                String m = resultSet.getString(10);
                String d = resultSet.getString(11);
                employee = new Employee(workId,address,brand,fn,mn,ln,s,sin,y,m,d);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return employee;
    }
    public List<Employee> findAllEmployees() {
        List<Employee> employees = new LinkedList<>();
        try {
            sql = "select * from Employee";
            ps = connection.prepareStatement(sql);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int workId = resultSet.getInt(1);
                String address = resultSet.getString(2);
                String brand = resultSet.getString(3);
                String firstName = resultSet.getString(4);
                String middleName = resultSet.getString(5);
                String lastName= resultSet.getString(6);
                double salary = resultSet.getDouble(7);
                long sinNumber = resultSet.getLong(8);
                String year = resultSet.getString(9);
                String month= resultSet.getString(10);
                String day= resultSet.getString(11);
                Employee employee = new Employee(workId, address,brand,firstName,middleName,lastName,salary,sinNumber,year,month,day);
                employees.add(employee);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return employees;
    }
    public List<Employee> findEmployeeByHotelBrand(String brand) {
        List<Employee> employees= new LinkedList<>();
        try {
            sql = "select * from Employee where brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, brand);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int workId = resultSet.getInt(1);
                String address = resultSet.getString(2);
                String fn = resultSet.getString(4);
                String mn = resultSet.getString(5);
                String ln = resultSet.getString(6);
                double s = resultSet.getDouble(7);
                long sin = resultSet.getLong(8);
                String y = resultSet.getString(9);
                String m = resultSet.getString(10);
                String d = resultSet.getString(11);
                Employee employee = new Employee(workId,address,brand,fn,mn,ln,s,sin,y,m,d);
                employees.add(employee);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employees;
    }
}
