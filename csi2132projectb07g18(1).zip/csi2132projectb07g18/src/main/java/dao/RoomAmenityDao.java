package dao;

import entities.RoomAmenty;

import java.sql.SQLException;

public class RoomAmenityDao extends  Dao{
    public RoomAmenty select(int roomNumber, String address, String brand){
        RoomAmenty roomAmenty = null;
        try {
            sql = "select * from room_amenity where address = ? and brand = ? and room_number = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,brand);
            ps.setInt(3,roomNumber);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                String amenity = resultSet.getString(4);
                roomAmenty = new RoomAmenty(address,brand,roomNumber,amenity);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return roomAmenty;
    }
    public void delete(int roomNumber, String address, String brand){
        try {


            sql = "delete * from room_amenity where address = ? and brand = ? and room_number = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, address);
            ps.setString(2, brand);
            ps.setInt(3, roomNumber);
            ps.executeUpdate();
        } catch (SQLException throwables) {

            throwables.printStackTrace();
        }

    }
    public void insert(RoomAmenty roomAmenty){
        try {
            sql = "insert into room_amenity values(?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,roomAmenty.getAddress());
            ps.setString(2,roomAmenty.getBrand());
            ps.setInt(3,roomAmenty.getRoomNumber());
            ps.setString(4,roomAmenty.getAmenity());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
//    private String address;
//    private String brand;
//    private int roomNumber;
//    private String amenity;
}
