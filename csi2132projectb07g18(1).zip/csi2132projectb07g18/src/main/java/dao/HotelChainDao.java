package dao;

import entities.HotelChain;

import java.sql.SQLException;

public class HotelChainDao extends Dao{
    public HotelChain select(String address, String brand){
        HotelChain hotelChain = null;
        try {
            sql = "select * from hotel_chain where address = ? and brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,brand);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                int star = resultSet.getInt(3);
                int nr = resultSet.getInt(4);
                String manager = resultSet.getString(5);
                hotelChain = new HotelChain(address,brand,star,nr,manager);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelChain;
    }
    public void delete(String address, String brand){
        try {
            sql = "delete * from hotel_chain where address = ? and brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,brand);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(HotelChain hotelChain){
        try {
            sql = "insert into hotel_chain values(?,?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,hotelChain.getAddress());
            ps.setString(2, hotelChain.getBrand());
            ps.setInt(3,hotelChain.getStar());
            ps.setInt(4,hotelChain.getNumOfRooms());
            ps.setString(5,hotelChain.getManager());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
