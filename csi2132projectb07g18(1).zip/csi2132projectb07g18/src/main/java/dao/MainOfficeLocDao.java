package dao;

import entities.MainOfficeLoc;

import java.sql.SQLException;

public class MainOfficeLocDao extends Dao{
    public MainOfficeLoc select(String brand, String location){
        MainOfficeLoc mainOfficeLoc = null;
        try {
            sql = "select * from main_office_loc where brand = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            ps.setString(2,location);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                mainOfficeLoc = new MainOfficeLoc(brand,location);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return mainOfficeLoc;
    }
    public void delete(String brand, String location){
        try {


            sql = "delete * from main_office_loc where brand = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, brand);
            ps.setString(2, location);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(MainOfficeLoc mainOfficeLoc){
        try {
            sql = "insert into main_office_loc values(?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,mainOfficeLoc.getBrand());
            ps.setString(2,mainOfficeLoc.getLocation());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
