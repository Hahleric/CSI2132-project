package dao;

import entities.HotelBrandPhoneNumber;

import java.sql.SQLException;

public class HotelBrandPhoneNumberDao extends Dao{
    public HotelBrandPhoneNumber select(String brand, String phone){
        HotelBrandPhoneNumber hotelBrandPhoneNumber = null;
        try {
            sql = "select * from hotel_brand_phone where brand = ? and phone = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            ps.setString(2,phone);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                hotelBrandPhoneNumber = new HotelBrandPhoneNumber(brand,phone);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelBrandPhoneNumber;
    }
    public void delete(String brand, String email){
        try {
            sql = "delete * from hotel_brand_phone where brand = ? and phone = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            ps.setString(2,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(HotelBrandPhoneNumber hotelBrandPhoneNumber){
        try {
            sql = "insert into hotel_brand_phone values(?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,hotelBrandPhoneNumber.getBrand());
            ps.setString(2,hotelBrandPhoneNumber.getPhoneNumber());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
