package dao;

import java.security.ProtectionDomain;
import java.sql.*;

public class Dao {
    protected String url;
    protected String userName;
    protected String pwd;
    protected String sql;
    protected PreparedStatement ps;
    protected ResultSet resultSet;
    protected Connection connection;


    public Dao(){
        this.url = "jdbc:postgresql://web0.site.uottawa.ca:15432/group_b07_g18";
        this.userName = "zcui014";
        this.pwd = "Canada7824";
    }

    public void connect(){
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            connection= DriverManager.getConnection(url,userName,pwd);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }
    public void update(String column, String value1, String condition, String value2){
        try {
            sql = "update bookInfo set ? = ? where ? = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,column);
            ps.setString(2,value1);
            ps.setString(3,condition);
            ps.setString(4,value2);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void close() {
        try {
            if (ps != null) {
                ps.close();
            }
            if (resultSet != null) {
                resultSet.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
