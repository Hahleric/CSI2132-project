package dao;
import entities.Customer;
import entities.Employee;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class LoginDao extends Dao{

    public String findEmployeeFirstNameById(int workId) {
        String firstName = null;
        try {
            sql = "select * from Employee where work_id = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1, workId);
            resultSet = ps.executeQuery();
            if (resultSet.next()) {
                firstName = resultSet.getString(4);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return firstName;
    }
    public String findCustomerFirstNameById(int id) {
        String firstName = null;
        try {
            sql = "select * from Customer where cust_id = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1, id);
            resultSet = ps.executeQuery();
            if (resultSet.next()) {
                firstName = resultSet.getString(2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return firstName;
    }

}