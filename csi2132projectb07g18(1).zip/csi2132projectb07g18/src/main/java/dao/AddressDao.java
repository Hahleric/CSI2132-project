package dao;

import entities.Address;
import entities.Customer;

import java.sql.SQLException;
import java.util.ArrayList;

public class AddressDao extends  Dao{
    public void insert( Address address){
        try {
            sql = "insert into address values (?,?,?,?,?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address.getLocation());
            ps.setString(2,address.getCountry());
            ps.setString(3,address.getProvinceOrState());
            ps.setString(4, address.getCity());
            ps.setString(5, address.getStreetNum());
            ps.setString(6,address.getStreetName());
            ps.setString(7, address.getAptNum());
            ps.setString(8,address.getZip());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void delete( String location){
        try {
            sql = "delete * from address where location = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,location);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public Address select( String location){
        Address address = null;
        try {

            sql = "select * from address where location = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,location);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                String country = resultSet.getString(2);
                String provinceOrState = resultSet.getString(3);
                String city = resultSet.getString(4);
                String streetNum = resultSet.getString(5);
                String streetName = resultSet.getString(6);
                String aptNum = resultSet.getString(7);
                String zip = resultSet.getString(9);
                address = new Address(location,country,provinceOrState,city,streetNum,streetName,aptNum,zip);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return address;
    }
    public void update(String column, String value1, String condition, String value2){
        try {
            sql = "update address set ? = ? where ? = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,column);
            ps.setString(2,value1);
            ps.setString(3,condition);
            ps.setString(4,value2);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
