package dao;

import entities.EmployeeEmail;
import entities.EmployeePosition;

import java.sql.SQLException;

public class EmployeePositionDao extends Dao {
    public EmployeePosition select(int workId, String brand, String address, String email){
        EmployeePosition employeeEmail = null;
        try {
            sql = "select * from employee_position where work_ID = ? and brand = ? and address = ? and position = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setString(4,email);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                employeeEmail = new EmployeePosition(workId,brand,address,email);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return employeeEmail;
    }
    public void insert(EmployeePosition employeeEmail){
        try {
            sql = "insert into employee_position values(?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,employeeEmail.getWorkId());
            ps.setString(2,employeeEmail.getBrand());
            ps.setString(3,employeeEmail.getAddress());
            ps.setString(4,employeeEmail.getPosition());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void delete(int workId, String brand, String address, String email){
        try {
            sql = "delete * from employee_position where work_ID = ? and brand = ? and address = ? and position = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setString(4,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
