package dao;

import entities.EmployeeEmail;
import entities.EmployeePhone;

import java.sql.SQLException;

public class EmployeePhoneDao extends Dao{
    public EmployeePhone select(int workId, String brand, String address, String email){
        EmployeePhone employeeEmail = null;
        try {
            sql = "select * from employee_phone where work_ID = ? and brand = ? and address = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setString(4,email);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                employeeEmail = new EmployeePhone(workId,brand,address,email);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return employeeEmail;
    }
    public void insert(EmployeePhone employeeEmail){
        try {
            sql = "insert into employee_phone values(?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,employeeEmail.getWordId());
            ps.setString(2,employeeEmail.getBrand());
            ps.setString(3,employeeEmail.getAddress());
            ps.setString(4,employeeEmail.getPhone());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void delete(int workId,String brand, String address, String email){
        try {
            sql = "delete * from employee_phone where work_ID = ? and brand = ? and address = ? and phone = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setString(4,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
