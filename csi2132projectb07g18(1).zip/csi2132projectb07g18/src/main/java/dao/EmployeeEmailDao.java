package dao;

import entities.Employee;
import entities.EmployeeEmail;

import java.sql.SQLException;

public class EmployeeEmailDao extends Dao{
    public EmployeeEmail select(int workId, String address,String brand, String email){
        EmployeeEmail employeeEmail = null;
        try {
            sql = "select * from employee_email where work_ID = ? and brand = ? and address = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setString(4,email);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                employeeEmail = new EmployeeEmail(workId,brand,address,email);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return employeeEmail;
    }
    public void insert(EmployeeEmail employeeEmail){
        try {
            sql = "insert into employee_email values(?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,employeeEmail.getWorkId());
            ps.setString(2,employeeEmail.getBrand());
            ps.setString(3,employeeEmail.getAddress());
            ps.setString(4,employeeEmail.getEmail());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void delete(int workId, String brand, String address,String email){
        try {
            sql = "delete * from employee_email where work_ID = ? and brand = ? and address = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setString(4,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
