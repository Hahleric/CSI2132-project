package dao;


import entities.CustAdder;
import entities.EmployeeAdder;

import java.sql.SQLException;

public class EmployeeAdderDao extends Dao{
    public EmployeeAdder select(int workId, String location, String address, String brand){
        EmployeeAdder employeeAdder = null;
        try {
            sql = "select * from employee_adder where work_ID = ? and location = ? and address = ? and brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,location);
            ps.setString(3,address);
            ps.setString(4,brand);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                employeeAdder = new EmployeeAdder(workId,address,brand,location);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return employeeAdder;
    }

    public void insert(EmployeeAdder employeeAdder){
        try {
            sql = "insert into employee_adder values(?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,employeeAdder.getWorkId());
            ps.setString(2,employeeAdder.getAddress());
            ps.setString(3, employeeAdder.getBrand());
            ps.setString(4, employeeAdder.getLocation());
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void delete(int workId, String address, String brand, String location){
        try {
            sql = "delete * from employee_adder where work_ID = ? and address = ? and brand = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,workId);
            ps.setString(2,address);
            ps.setString(3,brand);
            ps.setString(4,location);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
