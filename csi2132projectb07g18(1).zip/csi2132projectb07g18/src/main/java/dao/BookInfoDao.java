package dao;

import entities.*;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class BookInfoDao extends Dao{
    public List<Room> searchBookedRooms(String brand,String address,String year,String month,String day){
        List<Room> brooms = new LinkedList<Room>();
        Room room = null;
        try{
            sql = "select * from book_info where brand = ? and address = ? and year = ? and month = ? and day = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, brand);
            ps.setString(2, address);
            ps.setString(4,year);
            ps.setString(5,month);
            ps.setString(6,day);
            resultSet = ps.executeQuery();
            boolean booked;
            while (resultSet.next()) {
                int roomnumber = resultSet.getInt(1);
                double price = resultSet.getDouble(4);
                int capacity = resultSet.getInt(5);
                boolean isExtended = resultSet.getBoolean(6);
                boolean isSeaView = resultSet.getBoolean(7);
                boolean isMView = resultSet.getBoolean(8);
                booked= findIfRoomBooked(roomnumber,brand,address,year,month,day);
                if(booked == true){
                    room = new Room(roomnumber,address,brand,price,capacity,isExtended,isSeaView,isMView);
                    brooms.add(room);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return brooms;
    }
    public List<Room> searchAvailableRooms(String brand,String address,String year,String month,String day){
        List<Room> arooms = new LinkedList<Room>();
        Room room = null;
        try{
            sql = "select * from book_info where brand = ? and address = ? and year = ? and month = ? and day = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, brand);
            ps.setString(2, address);
            ps.setString(4,year);
            ps.setString(5,month);
            ps.setString(6,day);
            resultSet = ps.executeQuery();
            boolean booked;
            while (resultSet.next()) {
                int roomnumber = resultSet.getInt(1);
                double price = resultSet.getDouble(4);
                int capacity = resultSet.getInt(5);
                boolean isExtended = resultSet.getBoolean(6);
                boolean isSeaView = resultSet.getBoolean(7);
                boolean isMView = resultSet.getBoolean(8);
                booked= findIfRoomBooked(roomnumber,brand,address,year,month,day);
                if(booked == false){
                   room = new Room(roomnumber,address,brand,price,capacity,isExtended,isSeaView,isMView);
                   arooms.add(room);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return arooms;
    }
    public boolean findIfRoomBooked(int roomNum,String brand,String address,String year, String month,String day) {
        boolean isBooked = false;
        try{
            sql = "select * from book_info where room_number = ? and brand = ? and address = ? and year = ? and month = ? and day = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1, roomNum);
            ps.setString(2, brand);
            ps.setString(3, address);
            ps.setString(4,year);
            ps.setString(5,month);
            ps.setString(6,day);
            resultSet = ps.executeQuery();
            if (resultSet.next()) {
                isBooked = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return isBooked;
    }
    public void insert(BookInfo bookInfo){
        try {
            sql = "insert into book_info values(?,?,?,?,?,?,?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,bookInfo.getRoomNumber());
            ps.setString(2,bookInfo.getBrand());
            ps.setString(3,bookInfo.getAddress());
            ps.setInt(4,bookInfo.getCustId());
            ps.setInt(5,bookInfo.getBookId());
            ps.setString(6,bookInfo.getRoomType());
            ps.setString(8, bookInfo.getYear());
            ps.setInt(7,bookInfo.getNumOccupants());
            ps.setString(9,bookInfo.getMonth());
            ps.setString(10,bookInfo.getDay());
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void delete(int roomNum, String brand, String address,int custId, int bookId){
        try {
            sql = "delete * from book_info where room_number = ? and brand = ? and address = ? and cust_ID = ? and book_ID = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,roomNum);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.setInt(4,custId);
            ps.setInt(5,bookId);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public BookInfo select(int roomNum, String brand, String address,int custId, int bookId){
        BookInfo bookInfo = null;
        try {


            sql = "select * from book_info where room_number = ? and brand = ? and address = ? and cust_ID = ? and book_ID = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1, roomNum);
            ps.setString(2, brand);
            ps.setString(3, address);
            ps.setInt(4, custId);
            ps.setInt(5, bookId);
            resultSet = ps.executeQuery();
            if (resultSet.next()) {
                String roomType = resultSet.getString(6);
                int numOccupants = resultSet.getInt(7);
                String year = resultSet.getString(8);
                String month = resultSet.getString(9);
                String day = resultSet.getString(10);
                bookInfo = new BookInfo(roomNum,brand,address,custId,bookId,roomType,numOccupants,year,month,day);
            }

//            private String roomType;
//            private int NumOccupants;
//            private String year;
//            private String month;
//            private String day;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return bookInfo;
    }
}
