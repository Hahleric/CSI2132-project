package dao;

import entities.HotelChainEmail;
import entities.HotelChainPhone;

import java.sql.SQLException;

public class HotelChainPhoneDao extends Dao{
    public HotelChainPhone select(String address, String email){
        HotelChainPhone hotelChainEmail = null;
        try {
            sql = "select * from hotel_chain_phone where address = ? and phone = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,email);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                hotelChainEmail = new HotelChainPhone(address,email);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelChainEmail;
    }
    public void delete(String address, String email){
        try {
            sql = "delete * from hotel_chain_phone where address = ? and phone = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(HotelChainPhone hotelChainEmail){
        try {
            sql = "insert into hotel_chain_phone values(?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(2,hotelChainEmail.getPhoneNumber());
            ps.setString(1, hotelChainEmail.getAddress());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
