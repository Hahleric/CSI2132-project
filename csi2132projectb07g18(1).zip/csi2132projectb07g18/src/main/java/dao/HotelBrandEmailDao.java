package dao;

import entities.HotelBrandEmail;

import java.sql.SQLException;

public class HotelBrandEmailDao extends Dao{
    public HotelBrandEmail select(String brand, String email){
        HotelBrandEmail hotelBrandEmail = null;
        try {
            sql = "select * from hotel_brand_email where brand = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            ps.setString(2,email);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                hotelBrandEmail = new HotelBrandEmail(brand,email);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelBrandEmail;
    }
    public void delete(String brand, String email){
        try {
            sql = "delete * from hotel_brand_email where brand = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            ps.setString(2,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(HotelBrandEmail hotelBrandEmail){
        try {
            sql = "insert into hotel_brand_email values(?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,hotelBrandEmail.getBrand());
            ps.setString(2,hotelBrandEmail.getEmail());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
