package dao;

import entities.HotelBrand;

import java.sql.SQLException;

public class HotelBrandDao extends Dao{
    public HotelBrand select(String brand){
        HotelBrand hotelBrand = null;
        try {
            sql = "select * from hotel_brand where brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            resultSet = ps.executeQuery();
            if(resultSet.next()){
                String main = resultSet.getString(2);
                String numC = resultSet.getString(3);
                hotelBrand = new HotelBrand(brand,main,numC);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelBrand;
    }
    public void delete(String brand){
        try {
            sql = "delete * from hotel_brand where brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,brand);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(HotelBrand hotelBrand){
        try {
            sql = "insert into hotel_brand values(?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,hotelBrand.getBrand());
            ps.setString(2, hotelBrand.getMainOfficeLocation());
            ps.setString(3, hotelBrand.getNumChains());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
