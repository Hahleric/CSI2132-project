package dao;

import entities.CustAdder;

import java.sql.SQLException;

public class CustAdderDao extends Dao{
    public void insert(CustAdder custAdder){
        try {
            sql = "insert into cust_adder values(?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,custAdder.getCustId());
            ps.setString(2,custAdder.getLocation());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }


    }
    public void delete(int custId, String location){
        try {
            sql = "delete * from cust_adder where cust_id = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,custId);
            ps.setString(2,location);
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public CustAdder select(int custId, String location){
        CustAdder custAdder = null;
        try {
            sql = "select * from cust_adder where cust_id = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,custId);
            ps.setString(2,location);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                custAdder = new CustAdder(custId,location);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return custAdder;
    }

}
