package dao;

import entities.HotelAdder;

import java.sql.SQLException;

public class HotelAdderDao extends Dao {
    public HotelAdder select(String address, String brand, String brandLocation){
        HotelAdder hotelAdder = null;
        try {
            sql = "select * from hotel_adder where address = ? and brand = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,brand);
            ps.setString(3,brandLocation);
            resultSet = ps.executeQuery();
            if(resultSet.next()){
                hotelAdder = new HotelAdder(address,brand,brandLocation);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelAdder;
    }
    public void insert(HotelAdder hotelAdder){
        try {
            sql = "insert into hotel_adder values(?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(1,hotelAdder.getAddress());
            ps.setString(2,hotelAdder.getBrand());
            ps.setString(3, hotelAdder.getLocation());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void delete(String address, String brand, String brandLocation){
        try {
            sql = "delete * from hotel_adder where address = ? and brand = ? and location = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,brand);
            ps.setString(3,brandLocation);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
