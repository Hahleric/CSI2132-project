package dao;

import entities.Customer;
import entities.Customer;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDao extends Dao{
    public ArrayList<Customer> getAllUsers(){
        ArrayList<Customer> customers = new ArrayList<Customer>();
        sql = "select * from customer";
        try {
            ps = connection.prepareStatement(sql);
            resultSet = ps.executeQuery();
            while(resultSet.next()){
                int ID = resultSet.getInt(1);
                String firstName = resultSet.getString(2);
                String middleName = resultSet.getString(3);
                String lastName = resultSet.getString(4);
                String sinNumber = resultSet.getString(5);
                String dateRegistration = resultSet.getString(6);
                Customer cus = new Customer(ID,firstName,middleName,lastName,sinNumber,dateRegistration);
                customers.add(cus);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return  customers;

    }
    public Customer findCusById(int Id){
        Customer customer = null;
        sql = "select * from customer where ID = ?";
        try {
            ps = connection.prepareStatement(sql);
            ps.setInt(1,Id);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                String firstName = resultSet.getString(2);
                String middleName = resultSet.getString(3);
                String lastName = resultSet.getString(4);
                String sinNumber = resultSet.getString(5);
                String dateRegistration = resultSet.getString(6);
                customer = new Customer(Id,firstName,middleName,lastName,sinNumber,dateRegistration);
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return customer;


    }
    public void insertCus(Customer customer){
        sql = "insert into customer values(?,?,?,?,?,?)";
        try {
            ps = connection.prepareStatement(sql);
            ps.setInt(1,customer.getID());
            ps.setString(2,customer.getFirstName());
            ps.setString(3,customer.getMiddleName());
            ps.setString(4,customer.getLastName());
            ps.setString(5,customer.getSinNumber());
            ps.setString(6,customer.getDateRegistration());
            ps.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }



    }
    public void removeCusById(int Id){
        sql = "delete from customer where ID = ?";  //在deleteCustomer里有用
        try {
            ps = connection.prepareStatement(sql);
            ps.setInt(1,Id);
            ps.executeUpdate();
        }catch (SQLException s){
            s.printStackTrace();
        }
    }

}
