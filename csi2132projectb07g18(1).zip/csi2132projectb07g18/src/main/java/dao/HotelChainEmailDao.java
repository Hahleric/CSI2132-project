package dao;

import entities.HotelBrandPhoneNumber;
import entities.HotelChainEmail;

import java.sql.SQLException;

public class HotelChainEmailDao extends Dao{
    public HotelChainEmail select(String address, String email){
        HotelChainEmail hotelChainEmail = null;
        try {
            sql = "select * from hotel_chain_email where address = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,email);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                hotelChainEmail = new HotelChainEmail(address,email);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return hotelChainEmail;
    }
    public void delete(String address, String email){
        try {
            sql = "delete * from hotel_chain_email where address = ? and email = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1,address);
            ps.setString(2,email);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(HotelChainEmail hotelChainEmail){
        try {
            sql = "insert into hotel_chain_email values(?,?)";
            ps = connection.prepareStatement(sql);
            ps.setString(2,hotelChainEmail.getEmail());
            ps.setString(1, hotelChainEmail.getAddress());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

}
