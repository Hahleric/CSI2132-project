package dao;

import entities.Employee;
import entities.Room;

import java.util.List;

public class Test {
    public static void main(String[] args) {
       /* EmployeeDao employeeDao = new EmployeeDao();
        employeeDao.connect();
        Employee employee = new Employee(234,"111 cooper","111","c"," ","C",1000,123456,"2020","12","11");

        employeeDao.insert(employee);
        Employee employee1 = employeeDao.select(123,"111 cooper", "111");
        System.out.println(employee1.toString());
        */
        /*EmployeeDao employeeDao = new EmployeeDao();
        employeeDao.connect();
        List<Employee> employees = employeeDao.findAllEmployees();
        employeeDao.close();
        System.out.println(employees);*/
        RoomDao roomDao = new RoomDao();
        roomDao.connect();
       /* Room room = new Room(2004,"180 lees","RiverS",200,2,true,false,false);
        roomDao.insert(room);
        roomDao.findRoomByBrand("Rivers");
        roomDao.close();
        */

    }
}
