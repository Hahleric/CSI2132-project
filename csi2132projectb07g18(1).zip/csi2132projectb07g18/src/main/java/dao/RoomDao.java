package dao;

import entities.Room;
import java.util.LinkedList;
import java.util.List;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

public class RoomDao extends Dao{
    public List<Room> findRoomByBrand(String brand) {
        List<Room> rooms= new LinkedList<>();
        try {
            sql = "select * from room where brand = ?";
            ps = connection.prepareStatement(sql);
            ps.setString(1, brand);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                int roomNumber = resultSet.getInt(1);
                String address = resultSet.getString(2);
                double price = resultSet.getDouble(4);
                int capacity = resultSet.getInt(5);
                boolean isExtended = resultSet.getBoolean(6);
                boolean isSeaView = resultSet.getBoolean(7);
                boolean isMountainView = resultSet.getBoolean(8);
                Room room = new Room(roomNumber,address,brand,price,capacity,isExtended,isSeaView,isMountainView);
                rooms.add(room);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }
    public Room select(int roomNumber, String brand, String address){
        Room room = null;
        try {
            sql = "select * from room where room_number = ? and brand = ? and address = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,roomNumber);
            ps.setString(2,brand);
            ps.setString(3,address);
            resultSet = ps.executeQuery();
            if (resultSet.next()){
                double price = resultSet.getDouble(4);
                int rc = resultSet.getInt(5);
                boolean ex = resultSet.getBoolean(6);
                boolean is = resultSet.getBoolean(7);
                boolean im = resultSet.getBoolean(8);
                room = new Room(roomNumber,brand,address,price,rc,ex,is,im);

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return room;
    }
    public void delete(int roomNumber, String brand, String address){
        try {
            sql = "delete * from room where room_number = ? and brand = ? and address = ?";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,roomNumber);
            ps.setString(2,brand);
            ps.setString(3,address);
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
    public void insert(Room room){
        try {
            sql = "insert into room values(?,?,?,?,?,?,?,?)";
            ps = connection.prepareStatement(sql);
            ps.setInt(1,room.getRoomNumber());
            ps.setString(2,room.getBrand());
            ps.setString(3,room.getAddress());
            ps.setDouble(4,room.getPrice());
            ps.setInt(5,room.getCapacity());
            ps.setBoolean(6,room.isExtended());
            ps.setBoolean(7,room.isSeaView());
            ps.setBoolean(8,room.isMountainView());
            ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
